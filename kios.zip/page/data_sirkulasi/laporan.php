<div class="panel panel-primary">
<div class="panel-heading">
Cetak Data Sirkulasi Pakan
</div>
 
 <div class="panel-body">

                            <div class="row">
                                <div class="col-md-12">
                                  
                                    <form method="POST" action="./laporan/laporan_sirkulasi.php">
                                        


                                        <div class="form-group">
                                            <label>Dari Tanggal:</label>
                                          	<input class="form-control" type="date" name="daritanggal"/>
                                        </div>

								
                                         <div class="form-group">
                                            <label>Sampai Tanggal</label>
                                          	<input class="form-control" type="date" name="sampaitanggal"/>
                                        </div>





                                        <div>
                                       			 <input type="submit" name="simpan" value="Cetak" class="btn btn-primary">
     									</div>

					</div>

					</form>
				</div>
    
</div>

</div>
    
</div>

