<div class="panel panel-primary">
<div class="panel-heading">
	Tambah Data 
</div>
 
 <div class="panel-body">

                            <div class="row">
                                <div class="col-md-12">

                             
                                  
                                    <form method="POST" action="?page=data_jadwal&aksi=simpan">
                                        <div class="form-group">
                                            <label>Tanggal</label>
                                          	<input class="form-control" type="date" name="tanggal"/>
                                        </div>

                                       <div class="form-group">
                                            <label>Jam</label>
                                          	<input type="time" class="form-control" name="jam"/>
                                        </div>

                                        <div class="form-group">
                                             <label>Judul</label>
                                            

<input type="text" name="title" class="form-control" >    

                                        </div>

                                          <div class="form-group">
                                            <label>Deskripsi</label>
                                            <textarea name="description" class="form-control"></textarea>

                                        </div>
                                        
<div>
                                             <input type="submit" name="simpan" value="Simpan" style="margin-top:" class="btn btn-primary">  

                                        </div>

                                       
                                        
                                        
					</form>
				</div>
    
</div>

</div>
    
</div>
              

