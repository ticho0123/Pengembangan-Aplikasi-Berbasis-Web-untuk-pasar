<div class="panel panel-primary">
<div class="panel-heading">
	Tambah Data 
</div>
 
 <div class="panel-body">

                            <div class="row">
                                <div class="col-md-12">
                                  
                                    <form method="POST" action="?page=data_suplier&aksi=simpan">
                                        

                                       <div class="form-group">
                                            <label>Nama</label>
                                          	<input class="form-control" name="nama_suplier"/>
                                        </div>

                                        <div class="form-group">
                                            <label>Alamat</label>
                                          	<input class="form-control" name="alamat_suplier"/>
                                        </div>

								
                                         <div class="form-group">
                                            <label>Telpon</label>
                                          	<input class="form-control" name="tlp_suplier"/>
                                        </div>

                                       
                                        <div>
                                       			 <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
     									</div>

					</div>

					</form>
				</div>
    
</div>

</div>
    
</div>

