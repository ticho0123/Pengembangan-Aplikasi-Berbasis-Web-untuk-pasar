<html>
<head>
<title>Backup Data</title>

</head>
<body>
    <h2>Backup Data Peternakan</h2>

    <form method="post" action="download/download.php" enctype="multipart/form-data"
        id="frm-restore">
        <div class="form-group">
           
        <div class="form-group">
            <input type="submit" name="download" value="Dowload Data"
                class="btn btn-primary" />
        </div>
    </form>
</body>
</html>