<?php


$koneksi = new mysqli("localhost","root","","pegawai");




 ?>
